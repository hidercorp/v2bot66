<?php

class TelegramException extends Exception{}
